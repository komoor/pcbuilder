package pl.komoor.pcbuilder.models.enums;

public enum EMemorySpeed {
    DDR4_1866,
    DDR4_2133,
}
