package pl.komoor.pcbuilder.payload.response.builds;

public class PcBuildReviewResponse {
}
