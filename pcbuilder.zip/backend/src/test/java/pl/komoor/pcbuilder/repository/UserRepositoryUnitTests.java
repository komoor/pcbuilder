//package pl.komoor.pcbuilder.repository;
//
//import static org.assertj.core.api.Assertions.*;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
//import org.springframework.boot.test.context.SpringBootTest;
//import pl.komoor.pcbuilder.models.users.User;
//import pl.komoor.pcbuilder.repository.users.UserRepository;
//
//import java.util.Optional;
//
//@SpringBootTest
//public class UserRepositoryUnitTests {
//
//    @Autowired
//    TestEntityManager entityManager;
//
//    @Autowired
//    UserRepository userRepository;
//
//    @Test
//    public void should_find_no_users_if_repository_empty() {
//        Iterable<User> users = userRepository.findAll();
//        assertThat(users).isEmpty();
//
//    }
//
//    @Test
//    public void should_add_user() {
//        User user = userRepository.save(new User("Test", "test@gmail.com", "123456"));
//
//        assertThat(user).hasFieldOrPropertyWithValue("username", "Test");
//        assertThat(user).hasFieldOrPropertyWithValue("email", "test@gmail.com");
//        assertThat(user).hasFieldOrPropertyWithValue("password", "123456");
//    }
//
//    @Test
//    public void should_get_user_by_username() {
//        User user1 = new User("Test1", "test1@gmail.com", "123456");
//        entityManager.persist(user1);
//
//        User user2 = new User("Test2", "test2@gmail.com", "123456");
//        entityManager.persist(user2);
//
//        Optional<User> foundUser = userRepository.findByUsername(user2.getUsername());
//        assertThat(foundUser.get()).isEqualTo(user2);
//    }
//
//    @Test
//    public void should_delete_user_by_id() {
//        User user1 = new User("Test1", "test1@gmail.com", "123456");
//        entityManager.persist(user1);
//
//        userRepository.deleteById(user1.getId());
//
//        Iterable<User> users = userRepository.findAll();
//
//        assertThat(users).isEmpty();
//    }
//
//    @Test
//    public void should_update_user_by_id() {
//        User user1 = new User("Test1", "test1@gmail.com", "123456");
//        entityManager.persist(user1);
//
//        User user2 = new User("Test2", "test2@gmail.com", "123456");
//        entityManager.persist(user2);
//
//        User updatedUser = new User("Test3", "utest@gmail.com", "123");
//
//        User user = userRepository.findById(user2.getId()).get();
//        user.setUsername(updatedUser.getUsername());
//        user.setEmail(updatedUser.getEmail());
//        user.setPassword(updatedUser.getPassword());
//        userRepository.save(user);
//
//        User checkUser = userRepository.findById(user2.getId()).get();
//
//        assertThat(checkUser.getId()).isEqualTo(user2.getId());
//        assertThat(checkUser.getUsername()).isEqualTo(updatedUser.getUsername());
//        assertThat(checkUser.getEmail()).isEqualTo(updatedUser.getEmail());
//        assertThat(checkUser.getPassword()).isEqualTo(updatedUser.getPassword());
//    }
//
//}
