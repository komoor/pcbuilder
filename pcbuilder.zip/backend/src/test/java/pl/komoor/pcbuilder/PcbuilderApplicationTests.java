package pl.komoor.pcbuilder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcbuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
